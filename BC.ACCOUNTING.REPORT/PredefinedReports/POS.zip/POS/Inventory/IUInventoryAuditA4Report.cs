﻿using System.ComponentModel;
using System.Diagnostics;
using BC.ACCOUNTING.REPORT.DTO.POS;
using BC.ACCOUNTING.REPORT.Helper;
using DevExpress.XtraReports.UI;

namespace BC.ACCOUNTING.REPORT.PredefinedReports.POS.Inventory
{
    public partial class IUInventoryAuditA4Report : XtraReport
    {
        public IUInventoryAuditA4Report()
        {
            InitializeComponent();
        }

        public IUInventoryAuditA4Report(InventoryDto dto, string reportName)
        {
            LoadLayoutFromXml(reportName);
            this.objectDataSource1.DataSource = dto;
            if(GroupHeader1 is not null)
                GroupHeader1.BeforePrint += GroupHeader1_BeforePrint;
            if (this.Parameters["DecimalPrecision"] is not null)
                this.DecimalPrecision.Value = dto.DecimalPrecision.GetEnumDescription();

        }

        public int RowNum { get; set; } = 0;
        public void GroupHeader1_BeforePrint(object sender, CancelEventArgs e)
        {
            RowNum++;
            if (xrTableCell2 is not null)
                xrTableCell2.Text = (RowNum).ToString();
            xrTableRow6.BackColor = RowNum % 2 == 0 ? System.Drawing.Color.WhiteSmoke : System.Drawing.Color.White;
        }
        public void GroupHeader2_BeforePrint(object sender, CancelEventArgs e)
        {
            RowNum=0;
        }
    }
}